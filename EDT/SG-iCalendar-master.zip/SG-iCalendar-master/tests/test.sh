#!/bin/sh

# aptitude install phpunit

phpunit AllTests.php
